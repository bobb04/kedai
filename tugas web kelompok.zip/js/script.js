// toggle class active
const navbarNav = document.querySelector('.navbar-nav');
document.querySelector('#hambuger-menu').
onclick = () =>{
    navbarNav.classList.toggle('active');
};


const hamburger = document.querySelector('#hamburger-menu').onclick = () => {
    navbarNav.classList.toggle('active');
};

document.addEventListener('click', function(e){
if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
    navbarNav.classList.remove('active');
}
});

function pesanKopi() {
    alert("Terima kasih! Pesanan Anda akan segera diproses.");
}

const hidden = document.querySelectorAll(".hidden");

const observer = new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
        if(entry.isIntersecting){
            entry.target.classList.add("show");
        }
    });
});

hidden.forEach(el=>{
    observer.observe(el);
});